﻿# Set our intial variables for loops and processing
$i = 1
$uri = 'https://functionapp20170915123638.azurewebsites.net/api/Function1'
$productID = "0334" # ProductID is static since this replicates a single product viral video
$iterations = 10 # Change this to iterate more or fewer times

# Begin Loop to iterate as many times as specified by $iterations. This loop checks if $i is prime, if it is, it set the order quantity to more than 1, otherwise it sets it to 1, to simulate real-world ordering.
while ($i -le $iterations) {
    
    # Prime checker
    $i2 = [math]::Round($i / 2)
    if ($i -le 3) {
        $quantity = Get-Random -Minimum 2 -Maximum 10 # Set quantity to more than 1 and less than 10
    }
    else {
        for ($q = 2; $q -le ($i2); $q++) {
            if (($i -gt 2) -and ($i % $q -eq 0)) {
                $quantity = 1
                break
            }
            else {
                $quantity = Get-Random -Minimum 2 -Maximum 10 # Set quantity to more than 1 and less than 10
            }
        }
    }
    
    # Semi-random CustomerID generator. All customer IDs start with 2305. A random four digit number as concatenated to this for a complete Customer ID.
    $customerIDmod = Get-Random -Minimum 1000 -Maximum 9999
    $customerID = "2305" + $customerIDmod

    $hash = @{  CustomerID  = $customerID; ProductID = $productID; Quantity = $quantity } # Create hash table of intial order values
    $JSON = $hash | convertto-json # Convert has table to JSON
    Invoke-WebRequest -UseBasicParsing -Uri $uri -Method POST -Body $JSON #Submit POST to web server specified by the URL entered at the top of this script
    $i = $i + 1
} # End Loop

Remove-Variable i
Remove-Variable uri
Remove-Variable productID
Remove-Variable iterations
Remove-Variable i2
Remove-Variable q
Remove-Variable quantity
Remove-Variable customerIDmod
Remove-Variable customerID
Remove-Variable hash
Remove-Variable JSON