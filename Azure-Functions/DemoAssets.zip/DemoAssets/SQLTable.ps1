﻿# Enter values for thumbprint and subscription ID 
$SQLServer = Read-Host 'Please enter your Azure SQL Server URL here'
$sqlpassword = Read-Host 'Please enter your Azure SQL Server Administrator Password here'

# Login in to Azure
Login-AzureRmAccount

#Save the T-SQL to create the table to a variable
$TableStatement = 'SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Orders](
	[OrderID] [bigint] IDENTITY(1,1) NOT NULL,
	[CustomerID] [nchar](10) NOT NULL,
	[ProductID] [nchar](10) NOT NULL,
	[Quantity] [int] NOT NULL
)
GO'

#Call the server and populate the table 
Invoke-Sqlcmd -Database AzureServerlessLab -ServerInstance $SQLServer -Username SQLAdmin -Password $sqlpassword -OutputSqlErrors $True -Query $TableStatement

#insert data into newly created table
$TableData = "INSERT INTO dbo.Orders VALUES ('23053947','0334','1')"

Invoke-Sqlcmd -Database AzureServerlessLab -ServerInstance $SQLServer -Username SQLAdmin -Password $sqlpassword -OutputSqlErrors $True -Query $TableData