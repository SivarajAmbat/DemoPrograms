import { Component } from '@angular/core';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // title = 'angular7features';
  // scrollitems:number[] = [];
  // constructor(){
  //   for(let index=0;index<10000;index++){
  //     this.scrollitems.push(index);
  //   }
  // }

  items = ['First', 'Second', 'Third', 'Fourth'];
  onDrop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.items, event.previousIndex, event.currentIndex);
  }

}
