﻿using System;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System.Web;
using System.IO;

namespace SendInlineAttachmentDemo.Dialogs
{
    [Serializable]
    public class RootDialog : IDialog<object>
    {
        public Task StartAsync(IDialogContext context)
        {
            context.Wait(MessageReceivedAsync);

            return Task.CompletedTask;
        }

        private async Task MessageReceivedAsync(IDialogContext context, IAwaitable<object> result)
        {
            var activity = await result as Activity;
            var reply = activity.CreateReply();

            Attachment attachment = GetInlineAttachment();
            reply.Attachments.Add(attachment);
            
            // Return our reply to the user
            await context.PostAsync(reply);

            context.Wait(MessageReceivedAsync);
        }

        private Attachment GetInlineAttachment()
        {
            var imagePath = HttpContext.Current.Server.MapPath("~/Images/tech-mahindra_416x416.jpg");
            var imageData = Convert.ToBase64String(File.ReadAllBytes(imagePath));

            return new Attachment
            {
                Name = "TechM.jpg",
                ContentType = "image/jpeg",
                ContentUrl = $"data:image.jpeg;base64,{imageData}"
            };
        }
    }
}