﻿using Microsoft.Bot.Builder.FormFlow;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FormFlowDemo
{
    public enum SandwichOptions
    { Vegetable, Chicken, Turkey, Tuna }

    public enum LengthOptions
    { SixInch, FootLong }

    public enum BreadOptions
    { Wheat, HoneyOat, ParmesanOregano, Flatbread }

    public enum CheeseOptions
    { ExtraCheese, CrispyBacon, SpicyPepperoni }

    public enum ToppingOptions
    { ShreddedLetuce, Cucumbers, Tomatoes, Onions, Capsicums, Olives, Jalapenos }

    public enum SauceOptions
    { RedChilli, Mustard, MintMayonnaise, Barbeque }



    [Serializable]
    public class SandwichOrder
    {
        public SandwichOptions? Sandwich;
        public LengthOptions? Length;
        public BreadOptions? Bread;
        public CheeseOptions? Cheese;
        public List<ToppingOptions> Toppings;
        public List<SauceOptions> Sauce;

        public static IForm<SandwichOrder> BuildForm()
        {
            return new FormBuilder<SandwichOrder>()
                .Message("Hi, This is the Sandwich Bot")
                .Build();
        }

    }
}