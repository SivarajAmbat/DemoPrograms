﻿using System;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System.Web;
using System.IO;

namespace SendUploadedAttachmentDemo.Dialogs
{
    [Serializable]
    public class RootDialog : IDialog<object>
    {
        public Task StartAsync(IDialogContext context)
        {
            context.Wait(MessageReceivedAsync);

            return Task.CompletedTask;
        }

        private async Task MessageReceivedAsync(IDialogContext context, IAwaitable<object> result)
        {
            var activity = await result as Activity;
            var reply = activity.CreateReply();

            var attachment = await GetUploadedAttachment(reply.ServiceUrl, reply.Conversation.Id);
            reply.Attachments.Add(attachment);

            // Return our reply to the user
            await context.PostAsync(reply);

            context.Wait(MessageReceivedAsync);
        }

        private async Task<Attachment> GetUploadedAttachment(string serviceUrl, string conversationId)
        {
            var imagePath = HttpContext.Current.Server.MapPath("~/Images/tech-mahindra_416x416.jpg");

            using (var connector = new ConnectorClient(new Uri(serviceUrl)))
            {
                var attachments = new Attachments(connector);
                var response = await attachments.Client.Conversations.UploadAttachmentAsync(
                    conversationId,
                    new AttachmentData
                    {
                        Name = "TechM.jpg",
                        OriginalBase64 = File.ReadAllBytes(imagePath),
                        Type = "image/jpeg"
                    });
                var attachmentUri = attachments.GetAttachmentUri(response.Id);
                return new Attachment
                {
                    Name = "TechM.jpg",
                    ContentType = "image/jpeg",
                    ContentUrl = attachmentUri
                };

            }
        }
    }
}