﻿using System;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;

namespace SendInternetAttachmentDemo.Dialogs
{
    [Serializable]
    public class RootDialog : IDialog<object>
    {
        public Task StartAsync(IDialogContext context)
        {
            context.Wait(MessageReceivedAsync);

            return Task.CompletedTask;
        }

        private async Task MessageReceivedAsync(IDialogContext context, IAwaitable<object> result)
        {
            var activity = await result as Activity;
            var reply = activity.CreateReply();

            var attachment = GetInternetAttachment();
            reply.Attachments.Add(attachment);

            // Return our reply to the user
            await context.PostAsync(reply);

            context.Wait(MessageReceivedAsync);
        }

        private Attachment GetInternetAttachment()
        {
            return new Attachment
            {
                Name = "TechM.jpg",
                ContentType = "image/jpeg",
                ContentUrl = @"https://www.techmahindra.com/_LAYOUTS/1033/STYLES/TechMahindra/DavidWrapper/images/TM-webbanner-desktop2.jpg"
            };
        }
    }
}